# Running the test network

```bash
  ./run_network.sh
```
# Shutdown the test network

```bash
  ./shutdown_network.sh
```

# Update chaincode

```bash
  ./update_chaincode.sh $VERSION
```
