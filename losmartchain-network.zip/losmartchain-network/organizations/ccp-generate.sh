#!/bin/bash

# Source the environment variables
. set_env.sh

function one_line_pem {
    echo "`awk 'NF {sub(/\\n/, ""); printf "%s\\\\\\\n",$0;}' $1`"
}

function json_ccp {
    local PP=$(one_line_pem $4)
    local CP=$(one_line_pem $5)
    sed -e "s/organization_name/$ORG/" \
        -e "s/organization_domain/$DOMAIN_OF_ORGANIZATION/" \
        -e "s/peer0/$PEER_1_LOWERCASE/" \
        -e "s/peer1/$PEER_2_LOWERCASE/" \
        -e "s/\${P0PORT}/$2/" \
        -e "s/\${P1PORT}/$6/" \
        -e "s/\${P2PORT}/$7/" \
        -e "s/\${P3PORT}/$8/" \
        -e "s/\${CAPORT}/$3/" \
        -e "s#\${PEERPEM}#$PP#" \
        -e "s#\${CAPEM}#$CP#" \
        organizations/ccp-template.json
}

function yaml_ccp {
    local PP=$(one_line_pem $4)
    local CP=$(one_line_pem $5)
    sed -e "s/organization_name/$ORG/" \
        -e "s/organization_domain/$DOMAIN_OF_ORGANIZATION/" \
        -e "s/peer0/$PEER_1_LOWERCASE/" \
        -e "s/peer1/$PEER_2_LOWERCASE/" \
        -e "s/\${P0PORT}/$2/" \
        -e "s/\${P1PORT}/$6/" \
        -e "s/\${P2PORT}/$7/" \
        -e "s/\${P3PORT}/$8/" \
        -e "s/\${CAPORT}/$3/" \
        -e "s#\${PEERPEM}#$PP#" \
        -e "s#\${CAPEM}#$CP#" \
        organizations/ccp-template.yaml | sed -e $'s/\\\\n/\\\n          /g'
}

ORG=$ORGANIZATION_NAME_LOWERCASE
P0PORT=7051
P1PORT=7052
P2PORT=7053
P3PORT=7054
CAPORT=7054
PEERPEM=organizations/peerOrganizations/$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/tlsca/tlsca.$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION-cert.pem
CAPEM=organizations/peerOrganizations/$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/ca/ca.$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $P1PORT $P2PORT $P3PORT)" > organizations/peerOrganizations/$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/connection-$ORGANIZATION_NAME_LOWERCASE.json
echo "$(yaml_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $P1PORT $P2PORT $P3PORT)" > organizations/peerOrganizations/$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/connection-$ORGANIZATION_NAME_LOWERCASE.yaml

ORG=$ORGANIZATION2_NAME_LOWERCASE
P0PORT=9051
P1PORT=9052
P2PORT=9053
P3PORT=9054
CAPORT=8054
PEERPEM=organizations/peerOrganizations/$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/tlsca/tlsca.$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION-cert.pem
CAPEM=organizations/peerOrganizations/$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/ca/ca.$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $P1PORT $P2PORT $P3PORT)" > organizations/peerOrganizations/$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/connection-$ORGANIZATION2_NAME_LOWERCASE.json
echo "$(yaml_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $P1PORT $P2PORT $P3PORT)" > organizations/peerOrganizations/$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/connection-$ORGANIZATION2_NAME_LOWERCASE.yaml
