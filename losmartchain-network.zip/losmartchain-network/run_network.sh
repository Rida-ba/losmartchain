GREEN='\033[0;32m'

function exportVariables(){

    # Organization information that you wish to build and deploy
    export NAME_OF_ORGANIZATION=$NAME_OF_ORGANIZATION
    export DOMAIN_OF_ORGANIZATION=$DOMAIN_OF_ORGANIZATION
    export ORGANIZATION_NAME_LOWERCASE=`echo "$NAME_OF_ORGANIZATION" | tr '[:upper:]' '[:lower:]'`
    export NAME_OF_ORGANIZATION2=$NAME_OF_ORGANIZATION2
    export ORGANIZATION2_NAME_LOWERCASE=`echo "$NAME_OF_ORGANIZATION2" | tr '[:upper:]' '[:lower:]'`
    export PEER_1=$PEER_1
    export PEER_2=$PEER_2
    export PEER_1_LOWERCASE=`echo "$PEER_1" | tr '[:upper:]' '[:lower:]'`
    export PEER_2_LOWERCASE=`echo "$PEER_2" | tr '[:upper:]' '[:lower:]'`

}

read -p "Organization Name 1: "  NAME_OF_ORGANIZATION
read -p "Organization Name 2: "  NAME_OF_ORGANIZATION2
read -p "Organization Domain: " DOMAIN_OF_ORGANIZATION
read -p "Banque 1: " PEER_1
read -p "Banque 2: " PEER_2

exportVariables

# Write variables to set_env.sh
cat <<EOF > set_env.sh
#!/bin/bash
export NAME_OF_ORGANIZATION=$NAME_OF_ORGANIZATION
export DOMAIN_OF_ORGANIZATION=$DOMAIN_OF_ORGANIZATION
export ORGANIZATION_NAME_LOWERCASE=$ORGANIZATION_NAME_LOWERCASE
export NAME_OF_ORGANIZATION2=$NAME_OF_ORGANIZATION2
export ORGANIZATION2_NAME_LOWERCASE=$ORGANIZATION2_NAME_LOWERCASE
export PEER_1=$PEER_1
export PEER_2=$PEER_2
export PEER_1_LOWERCASE=$PEER_1_LOWERCASE
export PEER_2_LOWERCASE=$PEER_2_LOWERCASE
EOF

# Source the environment variables
. set_env.sh

# Substitutes organizations information in the configtx template to match organizations name, domain and ip address
sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' ./configtx/configtx_template.yaml > ./configtx/configtx.yaml

# Substitutes organizations information in cryptogen
sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' ./organizations/cryptogen/crypto-config-org1_template.yaml > ./organizations/cryptogen/crypto-config-org1.yaml
sed -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' ./organizations/cryptogen/crypto-config-org2_template.yaml > ./organizations/cryptogen/crypto-config-org2.yaml
sed -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' ./organizations/cryptogen/crypto-config-orderer_template.yaml > ./organizations/cryptogen/crypto-config-orderer.yaml

# Substitutes organizations information in compose
sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' ./compose/compose-ca_template.yaml > ./compose/compose-ca.yaml
sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' -e "s/peer0_name/$PEER_1_LOWERCASE/g" -e "s/peer1_name/$PEER_2_LOWERCASE/g" ./compose/compose-test-net_template.yaml > ./compose/compose-test-net.yaml

# Substitutes organizations information in the docker-compose
sed -e 's/org1/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/org2/'$ORGANIZATION2_NAME_LOWERCASE'/g' -e 's/example.com/'$DOMAIN_OF_ORGANIZATION'/g' -e "s/peer0/$PEER_1_LOWERCASE/g" -e "s/peer1/$PEER_2_LOWERCASE/g" ./compose/docker/docker-compose-test-net_template.yaml > ./compose/docker/docker-compose-test-net.yaml

# Substitutes organizations domain in configUpdate.sh
sed -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' ./scripts/configUpdate_template.sh > ./scripts/configUpdate.sh

# Substitutes organizations vars in envVar.sh
sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' -e "s/peer0_name/$PEER_1_LOWERCASE/g" -e "s/peer1_name/$PEER_2_LOWERCASE/g" ./scripts/envVar_template.sh > ./scripts/envVar.sh

# Substitutes organizations vars in deployCC.sh
sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' ./scripts/deployCC_template.sh > ./scripts/deployCC.sh

# Clear network
./network.sh down

# Start network
ORGANIZATION_NAME_LOWERCASEMSP=${ORGANIZATION_NAME_LOWERCASE}MSP
ORGANIZATION2_NAME_LOWERCASEMSP=${ORGANIZATION2_NAME_LOWERCASE}MSP

./network.sh up createChannel -c ${ORGANIZATION_NAME_LOWERCASE}smartchain -ca && ./network.sh deployCC -c ${ORGANIZATION_NAME_LOWERCASE}smartchain -ccn firefly -ccp ./firefly/smart_contracts/fabric/firefly-go -ccl go -ccep "AND('$ORGANIZATION_NAME_LOWERCASEMSP.peer','$ORGANIZATION2_NAME_LOWERCASEMSP.peer')" && echo "${GREEN}${NAME_OF_ORGANIZATION} NETWORK DEPLOYMENT COMPLETED SUCCESSFULLY${NC}"


## Start firefly

# Substitutes firefly vars in ccp.yaml for fabconnector
ORG1_USER_KEYSTORE_DIR="./organizations/peerOrganizations/$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/users/Admin@$ORGANIZATION_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/msp/keystore"
ORG2_USER_KEYSTORE_DIR="./organizations/peerOrganizations/$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/users/Admin@$ORGANIZATION2_NAME_LOWERCASE.$DOMAIN_OF_ORGANIZATION/msp/keystore"
KEYSTORE=$(ls "$ORG1_USER_KEYSTORE_DIR")
KEYSTORE2=$(ls "$ORG2_USER_KEYSTORE_DIR")

sed -e 's/organization_name/'$ORGANIZATION_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' -e 's/mychannel/'${ORGANIZATION_NAME_LOWERCASE}smartchain'/g' -e 's/FILL_IN_KEY_NAME_HERE/'$KEYSTORE'/g' ./org1_ccp.yml  > ./${ORGANIZATION_NAME_LOWERCASE}_ccp.yml
sed -e 's/organization2_name/'$ORGANIZATION2_NAME_LOWERCASE'/g' -e 's/organization_domain/'$DOMAIN_OF_ORGANIZATION'/g' -e 's/mychannel/'${ORGANIZATION_NAME_LOWERCASE}smartchain'/g' -e 's/FILL_IN_KEY_NAME_HERE/'$KEYSTORE2'/g' ./org2_ccp.yml > ./${ORGANIZATION2_NAME_LOWERCASE}_ccp.yml

# Starting message
echo -e "${GREEN}FireFly with Fabric || Setup is about to start in 5 seconds...${NC}"
echo -e "${GREEN}to cancel CTRL+C${NC}"
sleep 5

# Stop and remove prod stack on FireFly if it is exist
ff stop ${ORGANIZATION_NAME_LOWERCASE}stack
echo "y" | ff remove ${ORGANIZATION_NAME_LOWERCASE}stack

# Start FireFly Fabric stack
ff init fabric ${ORGANIZATION_NAME_LOWERCASE}stack --ccp $PWD/${ORGANIZATION_NAME_LOWERCASE}_ccp.yml --msp "organizations" --ccp $PWD/${ORGANIZATION2_NAME_LOWERCASE}_ccp.yml --msp "organizations" --channel ${ORGANIZATION_NAME_LOWERCASE}smartchain --chaincode firefly 

# Replace docker-compose.override.yml with edited version
cd ~/.firefly/stacks/${ORGANIZATION_NAME_LOWERCASE}stack/
sudo rm docker-compose.override.yml
curl -sSLO https://raw.githubusercontent.com/cagatayuresin/firefly-with-fabric/main/docker-compose.override.yml

# Start stack
ff start ${ORGANIZATION_NAME_LOWERCASE}stack --verbose --no-rollback

