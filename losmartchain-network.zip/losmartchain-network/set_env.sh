#!/bin/bash
export NAME_OF_ORGANIZATION=lo
export DOMAIN_OF_ORGANIZATION=losmartchain.com
export ORGANIZATION_NAME_LOWERCASE=lo
export NAME_OF_ORGANIZATION2=pictet
export ORGANIZATION2_NAME_LOWERCASE=pictet
export PEER_1=peer0
export PEER_2=peer1
export PEER_1_LOWERCASE=peer0
export PEER_2_LOWERCASE=peer1
