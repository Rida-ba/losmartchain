./network.sh down
